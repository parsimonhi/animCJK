// chain animations after page load is complete
window.addEventListener('load',
	function(){
		if (animkanji.chainDone) return;animkanji.chainDone=1;
		var L,k,km,t=animkanji.duration;
		function getSvgId(p)
		{
			var e=p.parentNode;
			while (e.tagName!="svg") e=e.parentNode;
			return e.id;
		}
		L=document.querySelectorAll("svg.acjk.once path[clip-path],svg.acjk.infinite path[clip-path]");
		km=L.length;
		for (k=0;k<km;k++)
			L[k].style.animation=getSvgId(L[k])+"k "+t+"s linear both "+(k*t)+"s";
	},false);
