// start infinite loop after page load is complete
window.addEventListener('load',
	function(){
		if (animkanji.loopDone) return;animkanji.loopDone=1;
		var L,t=animkanji.duration,d=animkanji.delay;
		function getSvgId(p)
		{
			var e=p.parentNode;
			while (e.tagName!="svg") e=e.parentNode;
			return e.id;
		}
		function loop()
		{
			var L,k,km;
			L=document.querySelectorAll("svg.acjk.infinite path[clip-path]");
			km=L.length;
			if (km)
			{
				for(k=0;k<km;k++) L[k].style.animation="none";
				void document.body.offsetWidth;
				for(k=0;k<km;k++) L[k].style.animation=getSvgId(L[k])+"k "+t+"s linear both "+(k*t)+"s";
			}
		}
		function once()
		{
			var L;
			loop();
			L=document.querySelectorAll("svg.acjk.infinite path[clip-path]");
			setInterval(loop,(L.length*t+d)*1000);
		}
		L=document.querySelectorAll("svg.acjk.infinite path[clip-path],svg.acjk.once path[clip-path]");
		setTimeout(once,(L.length*t+d)*1000);
	},false);
