<?php 
/*
Plugin Name: AnimKanji plugin
Plugin URI: http://gooo.free.fr/animCjk/animkanji_wp_plugin_page.php
Description: Plugin for displaying kanji stroke by stroke
Author: François Mizessyn
Version: 1.06
Author URI: http://gooo.free.fr
*/

/*
Licenses: see "Licenses" folder.
*/

/*
Description
-----------
This Wordpress plugin allows to draw stroke by stroke animated kanji.
Kanji are stored in SVG files. The available kanji are currently the 2136 Jōyō kanji.

Installation (tested on wordpress 4.9)
--------------------------------------
1) Download plugin archive on your computer.
2) Open the wordpress admin page of your website.
3) Select "Plugins" from the left menu. The "Plugins" page displays.
4) Click on "Add New". The "Install Plugins" page displays.
5) Click on "Upload".
6) Click on "Select a file" button, look for the plugin archive, then click on "Install Now".
7) Click on "Activate Plugin".

Usage
-----
Insert somewhere in a wordpress page a string like:
[animkanji][/animkanji]
or
[animkanji]字[/animkanji] where "字" can be any jōyō kanji
or
[animkanji]一二三[/animkanji] where "一二三" can be any list of jōyō kanji

If no kanji is inserted between [animkanji] and [/animkanji],
the displayed kanji is chosen randomly in the whole jōyō kanji set.
If only one kanji is inserted between [animkanji] and [/animkanji],
it is displayed.
If a list of kanji is inserted between [animkanji] and [/animkanji],
the displayed kanji is chosen randomly in this list.
 
To display several kanji, just insert several [animkanji]...[/animkanji] in the page.
For instance, to display 漢字, insert:
[animkanji]漢[/animkanji][animkanji]字[/animkanji]

Options
-------
Some options can be set through the wordpress admin page of your web site. 
Click on "Settings" in the left menu, then on "AnimKanji", then modify what you want.

These options are:

animkanji_tag (default value: "animkanji"): can be any alphanumeric string. 
Change this value if "animkanji" tag is already used by another plugin.

animkanji_loop (default value: "2"):  can be 0, 1 or 2.
If 0, don't animate kanji.
If 1, play kanji animation only once.
If 2, play kanji animation as infinite loop.

animkanji_initial_color (default value: "#ccc"):  can be any css color.
Initial color of the kanji.

animkanji_drawing_color (default value: "#c00"):  can be any css color.
Color of a stroke during its drawing.

animkanji_final_color (default value: "#000"):  can be any css color.
Final color of the kanji.

animkanji_duration (default value: "1"):  can be any number.
Duration (in second) to draw one stroke.

animkanji_delay (default value: "1"):  can be any number.
Delay (in second) between two drawings.

Attributes
----------
It is also possible to use attributes to set loop and colors values for each kanji.

For instance:
[animkanji final_color="blue"]漢[/animkanji][animkanji final_color="orange"]字[/animkanji]

Style
-----
The kanji images display inside svg tag that have "acjk" as css class name.
By default, the width of the svg expands to fit its parent width.
To set the size of the svg or to add a border or anything else you want,
just add to the additional css of your website
some style for svg.acjk class.

For instance, to force the svg to be an image of 256px by 256px,
add to the additional css:
svg.acjk {width:256px;height:256px;}

Note: to add something to the additional css of your website,
go to Wordpress admin page, click on "Appearance",
then click on "Customize", then click on "Additional CSS".
*/

////-- options --////

add_option("animkanji_tag","animkanji");
add_option("animkanji_loop","2");
add_option("animkanji_initial_color","#ccc");
add_option("animkanji_drawing_color","#c00");
add_option("animkanji_final_color","#000");
add_option("animkanji_duration","1");
add_option("animkanji_delay","1");

////-- settings --////

class animkanji_settings
{
	// manage animkanji setting panel
	
    public function __construct()
    {
        if(is_admin())
    	{
			add_action("admin_menu",array($this,"animkanji_add_plugin_page"));
			add_action("admin_init",array($this,"animkanji_page_init"));
		}
    }
	
    public function animkanji_add_plugin_page()
    {
		// This page will be under "Settings"
		add_options_page
		(
			"Settings Admin",
			"AnimKanji",
			"manage_options",
			"animkanji-setting-admin",
			array($this,"animkanji_create_admin_page")
		);
    }

    public function animkanji_create_admin_page()
    {
		print "<div class=\"wrap\">";
	    screen_icon();
	    print "<h2>AnimKanji Settings</h2>";		
	    print "<form method=\"post\" action=\"options.php\">";
		settings_fields("animkanji_option_group");
		do_settings_sections("animkanji-setting-admin");
		submit_button();
	    print "</form>";
		print "</div>";
    }
	
    public function animkanji_page_init()
    {		
		register_setting("animkanji_option_group","animkanji_option_name",array($this,"animkanji_check_id"));
        add_settings_section
        (
        	"animkanji_setting_section_id",
        	" ",
        	array($this,"animkanji_print_section_info"),
        	"animkanji-setting-admin"
        );	
		add_settings_field
		(
	    	"animkanji_tag", 
	    	"Tag", 
	    	array($this,"animkanji_create_tag_field"),
	    	"animkanji-setting-admin",
	    	"animkanji_setting_section_id"
		);		
		add_settings_field
		(
	    	"animkanji_loop", 
	    	"Loop (0=none, 1=once or 2=infinite)", 
	    	array($this,"animkanji_create_loop_field"),
	    	"animkanji-setting-admin",
	    	"animkanji_setting_section_id"
		);		
		add_settings_field
		(
	    	"animkanji_initial_color", 
	    	"Initial color (css color)", 
	    	array($this,"animkanji_create_initial_color_field"),
	    	"animkanji-setting-admin",
	    	"animkanji_setting_section_id"
		);		
		add_settings_field
		(
	    	"animkanji_drawing_color", 
	    	"Drawing color (css color)", 
	    	array($this,"animkanji_create_drawing_color_field"),
	    	"animkanji-setting-admin",
	    	"animkanji_setting_section_id"
		);		
		add_settings_field
		(
	    	"animkanji_final_color", 
	    	"Final color (css color)", 
	    	array($this,"animkanji_create_final_color_field"),
	    	"animkanji-setting-admin",
	    	"animkanji_setting_section_id"
		);		
		add_settings_field
		(
	    	"animkanji_duration", 
	    	"Duration to draw 1 stroke (in second)", 
	    	array($this,"animkanji_create_duration_field"),
	    	"animkanji-setting-admin",
	    	"animkanji_setting_section_id"
		);		
		add_settings_field
		(
	    	"animkanji_delay", 
	    	"Delay between 2 drawings (in second)", 
	    	array($this,"animkanji_create_delay_field"),
	    	"animkanji-setting-admin",
	    	"animkanji_setting_section_id"
		);		
    }
	
    public function animkanji_check_id($input)
    {
    	$newInput=$input;
		update_option("animkanji_tag",$newInput["animkanji_tag"]);
		update_option("animkanji_loop",$newInput["animkanji_loop"]);
		update_option("animkanji_initial_color",$newInput["animkanji_initial_color"]);
		update_option("animkanji_drawing_color",$newInput["animkanji_drawing_color"]);
		update_option("animkanji_final_color",$newInput["animkanji_final_color"]);
		update_option("animkanji_duration",$newInput["animkanji_duration"]);
		update_option("animkanji_delay",$newInput["animkanji_delay"]);
		return $newInput;
    }
	
    public function animkanji_print_section_info()
    {
		print "Enter your settings below:";
	}
	
    public function animkanji_create_tag_field()
    {
    	print "<input type=\"text\" ";
    	print "id=\"input_animkanji_tag_id\" ";
    	print "name=\"animkanji_option_name[animkanji_tag]\" ";
    	print "value=\"".get_option("animkanji_tag")."\">";
    }
    
    public function animkanji_create_loop_field()
    {
    	print "<input type=\"text\" ";
    	print "id=\"input_animkanji_loop_id\" ";
    	print "name=\"animkanji_option_name[animkanji_loop]\" ";
    	print "value=\"".get_option("animkanji_loop")."\">";
    }

    public function animkanji_create_initial_color_field()
    {
    	print "<input type=\"text\" ";
    	print "id=\"input_animkanji_initial_color_id\" ";
    	print "name=\"animkanji_option_name[animkanji_initial_color]\" ";
    	print "value=\"".get_option("animkanji_initial_color")."\">";
    }

    public function animkanji_create_drawing_color_field()
    {
    	print "<input type=\"text\" ";
    	print "id=\"input_animkanji_drawing_color_id\" ";
    	print "name=\"animkanji_option_name[animkanji_drawing_color]\" ";
    	print "value=\"".get_option("animkanji_drawing_color")."\">";
    }

    public function animkanji_create_final_color_field()
    {
    	print "<input type=\"text\" ";
    	print "id=\"input_animkanji_final_color_id\" ";
    	print "name=\"animkanji_option_name[animkanji_final_color]\" ";
    	print "value=\"".get_option("animkanji_final_color")."\">";
    }

    public function animkanji_create_duration_field()
    {
    	print "<input type=\"text\" ";
    	print "id=\"input_animkanji_duration_id\" ";
    	print "name=\"animkanji_option_name[animkanji_duration]\" ";
    	print "value=\"".get_option("animkanji_duration")."\">";
    }

    public function animkanji_create_delay_field()
    {
    	print "<input type=\"text\" ";
    	print "id=\"input_animkanji_delay_id\" ";
    	print "name=\"animkanji_option_name[animkanji_delay]\" ";
    	print "value=\"".get_option("animkanji_delay")."\">";
    }
}

$animkanji_settings=new animkanji_settings();
$animkanji_counter=0;

////-- shortcode --////

function animkanji_decUnicode($u)
{
	$len=strlen($u);
	if ($len==0) return 63;
	$r1=ord($u[0]);
	if ($len==1) return $r1;
	$r2=ord($u[1]);
	if ($len==2) return (($r1&31)<< 6)+($r2&63);
	$r3=ord($u[2]);
	if ($len==3) return (($r1&15)<<12)+(($r2&63)<< 6)+($r3&63);
	$r4=ord($u[3]);
	if ($len==4) return (($r1& 7)<<18)+(($r2&63)<<12)+(($r3&63)<<6)+($r4&63);
	return 63;
}

function animkanji_sanitize_color($c)
{
	if (preg_match("/^#[A-Fa-f0-9]+$/",$c)) return $c;
	if (preg_match("/^rgba?\\([0-9,. ]+\\)$/",$c)) return $c;
	if (preg_match("/^[A-Za-z]+$/",$c)) return $c;
	return "#000";
}

function animkanji_shortcode_replace($atts,$content=null)
{
	// replace animkanji shortcode [animkanji]...[/animkanji]
	// by something like <svg ...>...</svg>
	global $animkanji_counter;
	$animkanji_counter++;
	$animkanjiLoop=intval(get_option("animkanji_loop"));
	$animkanjiInitialColor=animkanji_sanitize_color(get_option("animkanji_initial_color"));
	$animkanjiDrawingColor=animkanji_sanitize_color(get_option("animkanji_drawing_color"));
	$animkanjiFinalColor=animkanji_sanitize_color(get_option("animkanji_final_color"));
	$a=shortcode_atts(array("loop"=>$animkanjiLoop,
							"initial_color"=>$animkanjiInitialColor,
							"drawing_color"=>$animkanjiDrawingColor,
							"final_color"=>$animkanjiFinalColor),$atts);
	if ($a["loop"]!="") $animkanjiLoop=intval($a["loop"]);
	if ($a["initial_color"]!="") $animkanjiInitialColor=animkanji_sanitize_color($a["initial_color"]);
	if ($a["drawing_color"]!="") $animkanjiDrawingColor=animkanji_sanitize_color($a["drawing_color"]);
	if ($a["final_color"]!="") $animkanjiFinalColor=animkanji_sanitize_color($a["final_color"]);
	$animkanjiDuration=floatval(get_option("animkanji_duration"));
	$animkanjiDelay=floatval(get_option("animkanji_delay"));
	$s="";
	$dir="wp-content/plugins/animkanji_wp_plugin";
	if ($content)
	{
		$k=rand(0,mb_strlen($content,'UTF-8')-1);
		$u=mb_substr($content,$k,1,'UTF-8');
		$f=get_site_url()."/".$dir."/svgsJa/".animkanji_decUnicode($u).".svg";
	}
	else
	{
		$files=scandir(ABSPATH.$dir."/svgsJa");
		$k=rand(0,count($files)-1);
		while(pathinfo($files[$k],PATHINFO_EXTENSION)!="svg") $k=rand(0,count($files)-1);
    	$f=get_site_url()."/".$dir."/svgsJa/".$files[$k];
    }
	$svg=file_get_contents($f);
	if ($svg)
	{
		// assume $svg a svg record
		// rename id (case of multiple instances of the same kanji in the page)
		if (preg_match("/id=\"(z[0-9]+)\"/",$svg,$m))
			$svg=str_replace($m[1],$m[1]."_".$animkanji_counter,$svg);
		// must remove CDATA tag otherwise wp makes it dirty (it replaces > by &gt;)
		$svg=str_replace("<![CDATA[","",$svg);
		$svg=str_replace("]]>","",$svg);
		// add class
		if ($animkanjiLoop==0) $svg=str_replace("acjk","acjk static",$svg);
		else if ($animkanjiLoop==1) $svg=str_replace("acjk","acjk once",$svg);
		else $svg=str_replace("acjk","acjk infinite",$svg);
		// replace colors
		$svg=str_replace(
			array("#ccc","#c00","#000"),
			array("#initialGray","#drawingRed","#finalBlack"),
			$svg);
		$svg=str_replace(
			array("#initialGray","#drawingRed","#finalBlack"),
			array($animkanjiInitialColor,$animkanjiDrawingColor,$animkanjiFinalColor),
			$svg);
		if ($animkanjiLoop==0)
		{
			$svg=preg_replace("#<style>[\\s\\S]+</style>#","<style>\n#".$m[1]."_".$animkanji_counter." path {fill:".$animkanjiFinalColor.";}\n#".$m[1]."_".$animkanji_counter." path[clip-path] {fill:none;}\n</style>",$svg);
		}
		else if ($animkanjiLoop==1)
		{
			$scripts="<script>if(typeof animkanji==='undefined')var animkanji={};";
			$scripts.="animkanji.duration=".$animkanjiDuration.";";
			$scripts.="</script>\n";
			$scripts.="<script src='".get_site_url()."/".$dir."/animkanji_reset.js'></script>\n";
			$scripts.="<script src='".get_site_url()."/".$dir."/animkanji_chain.js'></script>\n";
		}
		else if ($animkanjiLoop==2)
		{
			$scripts="<script>if(typeof animkanji==='undefined')var animkanji={};";
			$scripts.="animkanji.duration=".$animkanjiDuration.";";
			$scripts.="animkanji.delay=".$animkanjiDelay.";";
			$scripts.="</script>\n";
			$scripts.="<script src='".get_site_url()."/".$dir."/animkanji_reset.js'></script>\n";
			$scripts.="<script src='".get_site_url()."/".$dir."/animkanji_chain.js'></script>\n";
			$scripts.="<script src='".get_site_url()."/".$dir."/animkanji_loop.js'></script>\n";
		}
		$svg=str_replace("</svg>","</svg>\n".$scripts,$svg);
		$s.=$svg;
	}
	else if ($content)
	{
		// display $content as is
		$s.="<div>".$content."</div>";
	}
	return $s;
}

add_shortcode(get_option('animkanji_tag'),'animkanji_shortcode_replace');

?>