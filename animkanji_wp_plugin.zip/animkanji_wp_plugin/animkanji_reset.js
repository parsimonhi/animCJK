(function(){
	// set path animations to none to avoid ugly side effect in case of long page load 
	if (animkanji.resetDone) return;animkanji.resetDone=1;
	L=document.querySelectorAll("svg.acjk.once path[clip-path],svg.acjk.infinite path[clip-path]");
	km=L.length;
	for (k=0;k<km;k++) L[k].style.animation="none";
})();
